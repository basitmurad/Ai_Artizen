package com.example.artizen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
